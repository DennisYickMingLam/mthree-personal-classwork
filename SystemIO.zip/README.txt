The Settings.cs file contains the file path for the text file.

The file format is as follows:

FirstName,LastName,Major,GPA
Eric,Wise,Business,4.0


