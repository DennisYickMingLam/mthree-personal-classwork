﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemIO.UI.Helpers
{
    public class Settings
    {
        public const string FilePath = @"C:\Data\SystemIO\Students.txt";
    }
}
